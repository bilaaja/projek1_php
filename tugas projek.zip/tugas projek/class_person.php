<?php 
class Person{
    public $nama;
    public $gender;
    public $tmp_lahir;
    public $tgl_lahir;
}

?>