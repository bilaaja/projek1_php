<?php
 include_once 'header.php';
 include_once 'sidebar.php';
?>
 <div class="content-wrapper">
<?php
require_once 'class_BMI.php';
require_once 'class_pasien.php';
require_once 'class_BMIPasien.php';

$psn1 = new Pasien("Alya Salsa","Jakarta","21-09-1999","P");
$psn1->gender="P";
$psn1->tmp_lahir="Jakarta";
$psn1->tgl_lahir="1999-09-21";

$psn2 = new Pasien("Albara","Tangerang","22-06-1999","L");
$psn2->gender="L";
$psn2->tmp_lahir="Tangerang";
$psn2->tgl_lahir="1999-06-22";

$psn3 = new Pasien("Nurkholifah","Bekasi","21-09-1998","P");
$psn3->gender="P";
$psn3->tmp_lahir="Bekasi";
$psn3->tgl_lahir="1998-09-21";

$psn4 = new Pasien("Salsabila","Bogor","21-09-1998","P");
$psn4->gender="P";
$psn4->tmp_lahir="Bogor";
$psn4->tgl_lahir="1998-09-21";

$bmi1 = new BMI("87","169","Alya Salsa");
$bmi2 = new BMI("95","165","Albara");
$bmi3 = new BMI("50","171","Nurkholifah");
$bmi4 = new BMI("48","168","Salsabila");

$bmip1 = new BMIPasien("P001","Alya Salsa","P","2022-01-10","24.7","Kelebihan Berat Badan",$psn1);
$bmip1->berat="87";
$bmip1->tinggi="169";
$bmip2 = new BMIPasien("P002","Albara","L","2022-01-10","20.3","Normal(ideal)",$psn2);
$bmip2->berat="95";
$bmip2->tinggi="165";
$bmip3 = new BMIPasien("P003","Nurkholifah","P","2022-01-11","15.4","Kekurangan Berat Badan",$psn3);
$bmip3->berat="50";
$bmip3->tinggi="171";
$bmip4 = new BMIPasien("P004","Salsabila","P","2022-01-11","15.4","Kekurangan Berat Badan",$psn4);
$bmip4->berat="48";
$bmip4->tinggi="168";

$ar_data = [$bmip1,$bmip2,$bmip3,$bmip4];

?>
<h1>Data BMI Pasien</h1>
<table class="table" bordered="1" width="100%">
    <thead>
        <tr>
            <th>NO</th><th>Tanggal Periksa</th><th>Kode Pasien</th><th>Nama pasien</th>
            <th>Gender</th><th>Berat(kg)</th><th>Tinggi(cm)</th><th>Nilai BMI</th><th>Status BMI</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $nomor=1;
            foreach($ar_data as $obj){
        ?>
            <tr>
                <td><?=$nomor?></td>
                <td><?=$obj->tanggal?></td>
                <td><?=$obj->id?></td>
                <td><?=$obj->nama?></td>
                <td><?=$obj->gender?></td>
                <td><?=$obj->berat?></td>
                <td><?=$obj->tinggi?></td>
                <td><?=$obj->nilai?></td>
                <td><?=$obj->status?></td>
            </tr>
        <?php
            $nomor++;
            }
        ?>
    </tbody>
</table>

<?php
 include_once 'footer.php';
?>



