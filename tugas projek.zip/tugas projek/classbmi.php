<?php
  class bmipasien {

    public $nama,
        $berat,
        $tinggi,
        $umur,
        $jeniskelamin;
    public function hasilBMI()
    {
        return "<b>Nama : $this->nama <br><br>
                Berat Badan : $this->berat <br><br>
                Tinggi Badan : $this->tinggi <br><br>
                Umur : $this->umur <br><br>
                Jenis Kelamin : $this->jeniskelamin <br><br>";
    }
    public function statusBMI($BMI)
    {
      if ($BMI < 18.5) {
         return "<td>kekurangan Berat Badan</td>";
       } else if ($BMI >= 18.5 && $BMI <= 24.9) {
         return "<td>Normal (ideal)</td>";
       } else if ($BMI >= 25.0 && $BMI <= 29.9) {
         return "<td>kelebihan Berat Badan</td>";
       } else {
         return "<td>kegemukan (obesitas)</td>";
       } 
    }
}
if(isset($_GET["nama__lengkap"])){
    $bmi = new bmipasien;
} 
$pasien1 = ['nama' => 'Alya Salsa', 'kelamin' => 'Perempuan', 'umur' => 20, 'berat' => 87, 'tinggi' => 169];
$pasien2 = ['nama' => 'Albara', 'kelamin' => 'Laki-laki', 'umur' => 18, 'berat' => 95, 'tinggi' => 171];
$pasien3 = ['nama' => 'Nurkholifah', 'kelamin' => 'Perempuan', 'umur' => 18, 'berat' => 50, 'tinggi' => 171];
$pasien4 = ['nama' => 'Salsabila', 'kelamin' => 'Perempuan', 'umur' => 18, 'berat' => 48, 'tinggi' => 168];

$ar_pasien = [$pasien1, $pasien2, $pasien3, $pasien4];
?>
      

